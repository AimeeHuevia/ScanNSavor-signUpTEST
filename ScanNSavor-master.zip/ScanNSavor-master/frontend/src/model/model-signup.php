<?php

//session_start();

// $host = "localhost";
// $user = "root";
// $pwd = "";
// $dbname = "scannsavor";

// $conn = mysqli_connect($host,$user,$pwd,$dbname);
// if(!$conn){
//     die("Not connected");
// }

// if(isset($_POST['register'])){
 
//     $email = mysqli_real_escape_string($conn, $_POST['txtEmail']);
//     $firstName = md5($_POST['txtFname']);
//     $lastName = md5($_POST['txtLname']);
//     $password = md5($_POST['txtPass']);
//     $cpassword = md5($_POST['txtCpass']);
 
//     $select = " SELECT * FROM users WHERE email = '$email' && password = '$pass' ";
    
//     $result = mysqli_query($conn, $select);
 
//     if(mysqli_num_rows($result) > 0){
 
//        $error[] = 'user already exist!';
 
//     }else{
 
//        if($pass != $cpass){
//           $error[] = 'password not matched!';
//        }else{
//           $insert = "INSERT INTO registration(email, fname, lname password, cpassword) VALUES('$email', '$firstName', '$lastName', $password', '$cpassword')";
//           mysqli_query($conn, $insert);
//           header('location:login.php');
//        }
//     }
 
//  };
 
 
// ?>

