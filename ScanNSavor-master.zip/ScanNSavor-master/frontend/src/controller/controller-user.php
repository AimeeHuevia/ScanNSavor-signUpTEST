<?php
require_once 'model/model-user.php';

class AuthController {
    public function handleAuthentication() {
        if (isset($_POST['signin'])) {
            $this->signin();
        } elseif(isset($_POST['signup'])) {
            $this->signup();
        }
        elseif (isset($_GET['logout'])) {
            $this->logout();
        }
    }

    public function signin() {
        $email = $_POST['txtEmail'];
        $password = md5($_POST['txtPass']);

        $database = new Database(); // Create a new instance of your Database class
        $conn = $database->connect(); // Get the existing database connection

        $query = "SELECT * FROM users WHERE email = :email AND password = :password";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":password", $password, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $_SESSION['user'] = $email;
            header("Location: index.php");
            exit();
        } else {
            echo "<script> alert('login failed!') </script>";
        }
    }

    public function logout() {
        session_destroy();
        header("Location: index.php");
        exit();
    }
    public function signup() {
        if (isset($_POST['signup'])) {
            $firstName = $_POST['txtFname'];
            $lastName = $_POST['txtLname'];
            $email = $_POST['txtEmail'];
            $password = $_POST['txtPass'];
            $cpassword = $_POST['txtCpass'];

            $userModel = new User();
            $existingUser = $userModel->getUserByEmail($email);

            if ($existingUser) {
                $error = 'User with this email already exists.';
            } else {
                if ($password != $cpassword) {
                    $error = 'Passwords do not match.';
                } else {
                    $userModel->createUser($firstName, $lastName, $email, $password);
                    header('location: login.php');
                    exit();
                }
            }
        }
    }
}